import { useEffect, useState, useRef } from 'react'; 
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isIdle, setIsIdle] = useState(false); 
  const typingTimeout = useRef(null); 
  
  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 3000);
  }, []);

  const handleUserInput = () => {
    setIsIdle(false); 

    if (typingTimeout.current) {
      clearTimeout(typingTimeout.current);
    }

    typingTimeout.current = setTimeout(() => {
      setIsIdle(true); 
    }, 3000);
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          <label>
            Input:
            <input type="text" onKeyUp={handleUserInput} />
          </label>
          <p>{isIdle ? 'User is idle...' : 'User is typing...'}</p>
        </div>
      )}
    </>
  );
}
