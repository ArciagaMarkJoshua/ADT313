import React, { useRef } from 'react';

function Problem3() {
 
  const inputRefs = [
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null)
  ];

  const handleButtonClick = () => {
    for (let i = 0; i < inputRefs.length; i++) {
      if (inputRefs[i].current && inputRefs[i].current.value === '') {
        inputRefs[i].current.focus();
        break;
      }
    }
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input ref={inputRefs[0]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input ref={inputRefs[1]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input ref={inputRefs[2]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input ref={inputRefs[3]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input ref={inputRefs[4]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input ref={inputRefs[5]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input ref={inputRefs[6]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input ref={inputRefs[7]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input ref={inputRefs[8]} type="text" />
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input ref={inputRefs[9]} type="text" />
      </div>
      <button type="button" onClick={handleButtonClick}>
        I'm a button
      </button>
    </>
  );
}

export default Problem3;
